package AreaOfR;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AreaOfRectangle a1 = new AreaOfRectangle();
		
		a1.setDim(10,20);
		int area = a1.getArea();
		
		System.out.println(area);
	}

}
