package java_28_05;

public class Employee extends Member{
	String specialization;
}
