package java_28_05;

public class Manager extends Member{
	 String department;
}
