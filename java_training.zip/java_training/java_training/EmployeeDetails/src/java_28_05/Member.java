package java_28_05;

public class Member {
	String name;
    int age;
    int phoneNumber;
    String address;
    double salary;
    
    public void printSalary() {
        System.out.println("Salary: " + salary);
    }
}
