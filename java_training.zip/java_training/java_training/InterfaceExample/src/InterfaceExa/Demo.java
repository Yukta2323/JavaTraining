package InterfaceExa;

public class Demo {

	public static void main(String[] args) {
		Display d1 = new Display();
		
		d1.showData();
	}

}
