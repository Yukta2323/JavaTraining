package InterfaceExa;

public class Display implements Printable{
	
	@Override
	public void showData()
	{
		System.out.println("I am Yash Sabhani.");
	}
}
