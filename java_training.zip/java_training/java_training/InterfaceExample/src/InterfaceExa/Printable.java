package InterfaceExa;

public interface Printable {
	int MIN = 10;
	void showData();
}
