package com.tnsif.testcases;

import org.junit.jupiter.api.Test;

public class MyFirstTest {

	@Test
	void display() {
		System.out.println("Hello World");
	}
}
