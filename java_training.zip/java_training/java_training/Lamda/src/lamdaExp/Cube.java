package lamdaExp;

@FunctionalInterface
public interface Cube {

		int calculate(int a); //Only one abstract method
		//int sqr(int n);
}
