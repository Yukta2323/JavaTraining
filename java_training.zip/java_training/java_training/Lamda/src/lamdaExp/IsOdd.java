package lamdaExp;

@FunctionalInterface
public interface IsOdd {

	public boolean checkOdd(int a);
}
