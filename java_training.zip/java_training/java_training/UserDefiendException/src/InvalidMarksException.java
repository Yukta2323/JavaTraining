
public class InvalidMarksException extends Exception{

	public InvalidMarksException() {
		super();
	}
	
	public InvalidMarksException(String msg) {
		super(msg);
	}
}
