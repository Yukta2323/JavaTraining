package covariantexample;

public class A {
	
	A show() {
		System.out.println("This is SuperClass.");
		return this;
	}
}
