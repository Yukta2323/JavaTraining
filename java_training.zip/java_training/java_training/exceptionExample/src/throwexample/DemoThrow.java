package throwexample;

public class DemoThrow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowExample1 tre = new ThrowExample1();
		
		tre.setScore(12);
		System.out.println(tre);
	}

}
