package Shape;

public class Square extends Rectangle{
	public void setSide(double side) {
        setLength(side);
        setBreadth(side);
    }
}
