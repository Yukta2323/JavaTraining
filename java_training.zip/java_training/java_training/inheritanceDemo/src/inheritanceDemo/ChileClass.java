package inheritanceDemo;

public class ChileClass extends BaseClass {

}
