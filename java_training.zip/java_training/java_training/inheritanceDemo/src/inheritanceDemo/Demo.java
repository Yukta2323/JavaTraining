package inheritanceDemo;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SuperBaseClass s1 = new SuperBaseClass();
		BaseClass b = new BaseClass();
		b.intro();
		b.setValue(10);
		
		System.out.println(b);

}
}
