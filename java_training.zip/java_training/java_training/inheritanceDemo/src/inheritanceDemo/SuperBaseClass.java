package inheritanceDemo;

public class SuperBaseClass {
	
	public void intro() {
	System.out.println("This is a SuperBaseClass");
	}
}
