package java_30_05;

public class DefaultExample implements Register{

	
	public void showReceipt() {
		System.out.println("My Receipt");
	}
}
