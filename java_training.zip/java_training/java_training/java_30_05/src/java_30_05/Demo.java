package java_30_05;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FuntionalInterface f1 = new FuntionalInterface();
		f1.sayHello();
		
		DefaultExample dfe = new DefaultExample();
		dfe.getId();
		dfe.showReceipt();
	}

}
