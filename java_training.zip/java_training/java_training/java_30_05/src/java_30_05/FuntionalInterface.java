package java_30_05;

public class FuntionalInterface implements GreetInterface  {

		@Override
		public void sayHello() {
			System.out.println("Hello world..");
		}
		
}
