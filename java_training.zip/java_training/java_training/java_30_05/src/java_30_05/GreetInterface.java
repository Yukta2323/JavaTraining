package java_30_05;

public interface GreetInterface extends Register{
	void sayHello();
	default void getId() {
		
	}
}
