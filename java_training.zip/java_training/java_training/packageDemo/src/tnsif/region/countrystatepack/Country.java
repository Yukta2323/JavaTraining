package tnsif.region.countrystatepack;

public class Country {

	private String countryname;

	public String getCname() {
		return countryname;
	}

	public void setCname(String countryname) {
		this.countryname = countryname;
	}
}
