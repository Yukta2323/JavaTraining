package wrapperclassexample;
import java.util.*;

public class WrraperClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k=32,j,l;
		char ch;
		
		Integer in = new Integer(12);
		in = k;
		
		//List <Integer> ls = new List <Integer>();
		
		Integer.parseInt("23");
		
	}

}
